package com.example.emploi_du_temps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmploiDuTempsApplicationTests {

	@Test
	void contextLoads() {
	}

}
